# Builds the original Shadow Entity: metaball body -> game mesh, armature, weights,
# rest-position UVs for stable shader noise, six actions, FBX export, check renders.
# Run: blender -b --factory-startup --python build_entity.py
import bpy, bmesh, math, random, os
import numpy as np
from mathutils import Vector, Matrix, noise
from bpy_extras import anim_utils

OUT = r"F:\agentic-os\projects\shadow-entity\blender"
# metaball field = s*(1-d^2/R^2)^3, threshold 0.6: visible radius / R is 0.575 at s=2 (probed), 0.396 at s=1
KS = {2.0: 1 / 0.575, 1.0: 1 / 0.3957}
STIFF = [1.0]   # soft blending for body masses; hands use 2.0
TARGET_TRIS = 24000
random.seed(7)

bpy.ops.wm.read_factory_settings(use_empty=True)
scene = bpy.context.scene
scene.render.fps = 30

def V(*a): return Vector(a)
X, Y, Z = V(1, 0, 0), V(0, 1, 0), V(0, 0, 1)
FWD, UP = V(0, -1, 0), V(0, 0, 1)

# ---------------------------------------------------------------- body (metaballs)
mb = bpy.data.metaballs.new("EntityMB")
mb.resolution = mb.render_resolution = 0.004
mb.threshold = 0.6
mbo = bpy.data.objects.new("EntityMB", mb)
scene.collection.objects.link(mbo)

def _el(kind, r):
    el = mb.elements.new(type=kind); el.stiffness = STIFF[0]; el.radius = r * KS[STIFF[0]]
    return el

def ball(p, r, neg=False):
    el = _el('BALL', r); el.co = p; el.use_negative = neg

def caps(a, b, r, neg=False):
    a, b = Vector(a), Vector(b); d = b - a
    el = _el('CAPSULE', r); el.co = (a + b) / 2
    el.size_x = d.length / 2
    el.rotation = X.rotation_difference(d.normalized()); el.use_negative = neg

def ell(p, half, neg=False):
    r = min(half)
    el = _el('ELLIPSOID', r); el.co = p
    el.size_x, el.size_y, el.size_z = half[0] / r, half[1] / r, half[2] / r
    el.use_negative = neg

# Head: elongated skull, deep sockets, gaunt cheeks, long open jaw (Blender: front = -Y, left = +X)
HC = V(0.004, -0.005, 2.215)
ell(HC, (0.084, 0.104, 0.118))
ell(HC + V(0, 0.045, 0.04), (0.076, 0.086, 0.088))
ell(HC + V(0.004, 0.085, 0.07), (0.052, 0.062, 0.052))
for s_ in (-1, 1):
    ell(HC + V(s_ * 0.042, -0.09, 0.038), (0.024, 0.013, 0.011))                  # brow ridges
    ell(HC + V(s_ * 0.058, -0.062, -0.022), (0.016, 0.03, 0.016))                 # cheekbones
    caps(HC + V(s_ * 0.06, -0.012, -0.055), HC + V(s_ * 0.022, -0.078, -0.135), 0.017)  # long jaw
    ball(HC + V(s_ * 0.072, -0.035, -0.06), 0.022, neg=True)                      # cheek hollows
ball(HC + V(0, -0.082, -0.14), 0.019)                                            # chin
caps(HC + V(0, -0.1, 0.035), HC + V(0, -0.11, -0.022), 0.011)                    # nose bridge
for s_, dz in ((-1, 0.0), (1, 0.008)):
    ell(HC + V(s_ * 0.042, -0.108, 0.006 + dz), (0.022, 0.034, 0.025), neg=True)  # deep sockets
ell(HC + V(0, -0.11, -0.032), (0.012, 0.024, 0.022), neg=True)                   # nasal cavity
ell(HC + V(0.004, -0.1, -0.104), (0.02, 0.04, 0.032), neg=True)                  # open mouth

# Neck + tendons
caps(V(0, 0.035, 1.93), V(0.003, 0.005, 2.12), 0.046)
for s in (-1, 1):
    caps(V(s * 0.05, 0.02, 2.15), V(s * 0.03, -0.045, 1.9), 0.011)

# Shoulder girdle (asymmetric: right side lower and narrower)
SL, SR = V(0.272, 0.035, 1.865), V(-0.255, 0.045, 1.832)
caps(V(0.035, 0.05, 1.965), SL + V(-0.03, 0, 0.01), 0.046)
caps(V(-0.035, 0.05, 1.96), SR + V(0.03, 0, 0.01), 0.043)
caps(V(0.02, -0.06, 1.885), SL + V(-0.02, -0.03, 0), 0.016)
caps(V(-0.02, -0.06, 1.88), SR + V(0.02, -0.03, 0), 0.016)
ball(SL, 0.06); ball(SR, 0.056)
for s, S_ in ((1, SL), (-1, SR)):
    ell(S_ + V(-s * 0.1, -0.035, -0.07), (0.075, 0.04, 0.06))                  # pectorals
    ell(S_ + V(-s * 0.08, 0.075, -0.13), (0.06, 0.035, 0.12))                  # lats

# Rib cage
CC = V(0, 0.03, 1.68)
ell(CC, (0.17, 0.112, 0.2))
ell(V(0, 0.04, 1.8), (0.19, 0.1, 0.08))
for s in (-1, 1):
    ell(V(s * 0.09, 0.113, 1.78), (0.05, 0.015, 0.07))                          # scapulae
for k in range(5):
    z0 = 1.70 - 0.05 * k
    f = math.sqrt(max(0.05, 1 - ((z0 - CC.z) / 0.19) ** 2))
    ax, ay = 0.17 * f - 0.002, 0.112 * f - 0.002
    for s in (-1, 1):
        pts = []
        for i in range(6):
            th = math.radians(18 + 140 * i / 5)
            pts.append(V(s * ax * math.sin(th), CC.y - ay * math.cos(th),
                         z0 - 0.06 * math.cos(th) + (0.004 if s > 0 else 0)))
        for a, b in zip(pts, pts[1:]):
            caps(a, b, 0.008)
caps(V(0, -0.074, 1.83), V(0, -0.07, 1.6), 0.014)                                # sternum

# Waist, spine, pelvis
caps(V(0, 0.05, 1.55), V(0, 0.035, 1.22), 0.08)
for i in range(17):
    z = 1.22 + 0.045 * i
    ball(V(0.002 * math.sin(i), 0.124 if z < 1.55 else 0.138, z), 0.015)
for s in (-1, 1):
    caps(V(s * 0.1, 0.0, 1.52), V(s * 0.07, -0.02, 1.27), 0.024)
ell(V(0, 0.02, 1.15), (0.1, 0.07, 0.065))
for s in (-1, 1):
    caps(V(s * 0.115, 0.02, 1.19), V(s * 0.065, -0.06, 1.12), 0.018)

# Lower body: leg stumps and tendrils of mist
def tendril(p0, r0, r1, zend, twist, phase, amp, n=9):
    pts = []
    for i in range(n + 1):
        t = i / n
        ang = phase + twist * t
        pts.append(V(p0.x + amp * t * math.cos(ang), p0.y + amp * t * math.sin(ang),
                     p0.z + (zend - p0.z) * t))
    for i in range(n):
        caps(pts[i], pts[i + 1], r0 + (r1 - r0) * ((i + 0.5) / n) ** 0.8)
    return pts

TENDRILS = {}
for s, nm in ((1, "L"), (-1, "R")):
    a, b = V(s * 0.085, 0.0, 1.1), V(s * 0.11, -0.03, 0.82)
    caps(a, b, 0.04)
    TENDRILS["Tail" + nm] = [a, b] + tendril(b, 0.042, 0.006, 0.22 if s > 0 else 0.3,
                                             3.2 * s, 0.6 + s, 0.11)[1:]
TENDRILS["TailC"] = tendril(V(0, 0.03, 1.08), 0.05, 0.005, 0.15, -2.6, 2.0, 0.09)
tendril(V(0.04, 0.06, 1.0), 0.02, 0.003, 0.45, 4.0, 3.5, 0.14, n=7)
tendril(V(-0.05, -0.02, 0.95), 0.018, 0.003, 0.5, -3.5, 5.0, 0.12, n=7)

# Arms and hands (left arm longer, fingers 15% longer)
FINGERS = [("Index", -0.036, -0.10, (0.085, 0.065, 0.055), 0.0105, (10, 16, 12)),
           ("Middle", -0.012, -0.03, (0.10, 0.076, 0.062), 0.011, (8, 14, 14)),
           ("Ring", 0.012, 0.045, (0.093, 0.07, 0.058), 0.0103, (12, 18, 10)),
           ("Pinky", 0.035, 0.13, (0.072, 0.056, 0.048), 0.0092, (14, 20, 16))]
ARMS = {}

def arm(S, side, upper, fore, a1, a2, fscale, nm):
    d1 = V(side * math.cos(math.radians(a1)), 0.02, -math.sin(math.radians(a1))).normalized()
    E = S + d1 * upper
    d2 = V(side * math.cos(math.radians(a2)), -0.03, -math.sin(math.radians(a2))).normalized()
    W = E + d2 * fore
    caps(S, E, 0.042)
    ball(E, 0.024)
    perp = d2.cross(Y).normalized() * 0.012
    caps(E.lerp(W, 0.08), E.lerp(W, 0.5), 0.03)
    caps(E + perp, W + perp * 0.8, 0.016); caps(E - perp * 0.6, W - perp, 0.014)
    ball(W, 0.022)
    STIFF[0] = 2.0
    d = d2
    s = (Y - d * Y.dot(d)).normalized()
    n = d.cross(s).normalized()
    if n.x * side > 0: n = -n                       # palm faces the body
    joints = {"S": S, "E": E, "W": W, "H": W + d * 0.075, "n": n, "fingers": {}}
    for name, off, spread, lengths, rb, curl in FINGERS:
        kn = W + d * 0.075 + s * off
        caps(W + s * off * 0.4 + d * 0.01, kn, 0.0095)
        ball(kn, rb * 1.15)
        dr = (d + s * spread).normalized(); p = kn; pts = [kn]
        for k, L in enumerate(lengths):
            q = p + dr * L * fscale
            caps(p, q, rb * (1 - 0.2 * k)); pts.append(q); p = q
            c = math.radians(curl[k])
            dr = (dr * math.cos(c) + n * math.sin(c)).normalized()
        joints["fingers"][name] = pts
    t0 = W + d * 0.018 - s * 0.026 + n * 0.012
    dr = (d * 0.55 - s * 0.65 + n * 0.45).normalized(); p = t0; pts = [t0]
    for k, L in enumerate((0.05, 0.045, 0.04)):
        q = p + dr * L * fscale
        caps(p, q, 0.0115 * (1 - 0.2 * k)); pts.append(q); p = q
        dr = (dr * math.cos(0.2) + n * math.sin(0.2)).normalized()
    joints["fingers"]["Thumb"] = pts
    ARMS[nm] = joints
    STIFF[0] = 1.0

arm(SL, 1, 0.48, 0.47, 40, 46, 1.15, "L")
arm(SR, -1, 0.45, 0.45, 42, 48, 1.0, "R")

# ---------------------------------------------------------------- metaball -> mesh
dg = bpy.context.evaluated_depsgraph_get()
me = bpy.data.meshes.new_from_object(mbo.evaluated_get(dg))
me.name = "ShadowEntityBody"
bpy.data.objects.remove(mbo)
body = bpy.data.objects.new("ShadowEntityBody", me)
scene.collection.objects.link(body)
print("metaball mesh verts", len(me.vertices), "faces", len(me.polygons))

bm = bmesh.new()
try:
    bm.from_mesh(me)
    bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=0.0005)
    # keep only the biggest connected piece (drops stray specks)
    seen, parts = set(), []
    for v in bm.verts:
        if v in seen: continue
        stack, part = [v], []
        seen.add(v)
        while stack:
            x = stack.pop(); part.append(x)
            for e in x.link_edges:
                o = e.other_vert(x)
                if o not in seen: seen.add(o); stack.append(o)
        parts.append(part)
    parts.sort(key=len, reverse=True)
    print("pieces", [len(p) for p in parts[:6]])
    for p in parts[1:]:
        if len(p) < 300: bmesh.ops.delete(bm, geom=p, context='VERTS')
    bm.normal_update()
    for v in bm.verts:   # organic unevenness along the normal
        c = v.co
        v.co = c + v.normal * (0.0035 * noise.noise(c * 9.0) + 0.002 * noise.noise(c * 23.0 + V(3, 1, 7)))
    bm.to_mesh(me)
finally:
    bm.free()

with bpy.context.temp_override(object=body, active_object=body, selected_objects=[body]):
    dec = body.modifiers.new("Dec", 'DECIMATE')
    dec.ratio = min(1.0, TARGET_TRIS / max(1, sum(len(p.vertices) - 2 for p in me.polygons)))
    bpy.ops.object.modifier_apply(modifier=dec.name)
    sm = body.modifiers.new("Smooth", 'SMOOTH'); sm.factor = 0.4; sm.iterations = 2
    bpy.ops.object.modifier_apply(modifier=sm.name)
me.shade_smooth()
print("final tris", sum(len(p.vertices) - 2 for p in me.polygons), "verts", len(me.vertices))

# rest-position UVs: UV0 = rest (x, z), UV1 = (rest y, mist mask: 1 at the bottom)
n = len(me.vertices)
co = np.empty(n * 3, np.float32); me.vertices.foreach_get("co", co); co = co.reshape(-1, 3)
li = np.empty(len(me.loops), np.int32); me.loops.foreach_get("vertex_index", li)
lc = co[li]
mask = np.clip((1.02 - lc[:, 2]) / 0.8, 0, 1) ** 1.3
uv0 = me.uv_layers.new(name="RestXZ"); uv0.data.foreach_set("uv", np.stack([lc[:, 0], lc[:, 2]], 1).ravel())
uv1 = me.uv_layers.new(name="RestYMask"); uv1.data.foreach_set("uv", np.stack([lc[:, 1], mask], 1).ravel())
mat = bpy.data.materials.new("ShadowEntityBody"); me.materials.append(mat)

# ---------------------------------------------------------------- armature
ad = bpy.data.armatures.new("ShadowEntityRig")
rig = bpy.data.objects.new("ShadowEntityRig", ad)
scene.collection.objects.link(rig)
BONES = [("Root", V(0, 0, 0), V(0, 0, 0.2), None),
         ("Hips", V(0, 0.02, 1.1), V(0, 0.035, 1.33), "Root"),
         ("Spine", V(0, 0.035, 1.33), V(0, 0.035, 1.56), "Hips"),
         ("Chest", V(0, 0.035, 1.56), V(0, 0.04, 1.9), "Spine"),
         ("Neck", V(0, 0.035, 1.93), V(0.003, 0.005, 2.12), "Chest"),
         ("Head", V(0.003, 0.005, 2.12), V(0.004, 0.0, 2.36), "Neck"),
         ("Jaw", V(0.004, -0.02, 2.165), V(0.004, -0.082, 2.078), "Head")]
for side, j in ARMS.items():
    sfx = "." + side
    BONES += [("Shoulder" + sfx, V(0.03 if side == "L" else -0.03, 0.04, 1.88), j["S"], "Chest"),
              ("UpperArm" + sfx, j["S"], j["E"], "Shoulder" + sfx),
              ("ForeArm" + sfx, j["E"], j["W"], "UpperArm" + sfx),
              ("Hand" + sfx, j["W"], j["H"], "ForeArm" + sfx)]
    for fname, pts in j["fingers"].items():
        parent = "Hand" + sfx
        for k in range(3):
            bn = f"{fname}{k + 1}{sfx}"
            BONES.append((bn, pts[k], pts[k + 1], parent)); parent = bn
for tname, pts in TENDRILS.items():
    idx = [0, 1, 4, 7, len(pts) - 1] if tname != "TailC" else [0, 3, 6, len(pts) - 1]
    parent = "Hips"
    for k in range(len(idx) - 1):
        bn = f"{tname}{k + 1}"
        BONES.append((bn, pts[idx[k]], pts[idx[k + 1]], parent)); parent = bn

bpy.context.view_layer.objects.active = rig
bpy.ops.object.mode_set(mode='EDIT')
for name, h, t, parent in BONES:
    eb = ad.edit_bones.new(name); eb.head = h; eb.tail = t
    if parent:
        eb.parent = ad.edit_bones[parent]
        eb.use_connect = (ad.edit_bones[parent].tail - h).length < 1e-4
    eb.use_deform = name != "Root"
bpy.ops.object.mode_set(mode='OBJECT')

for o in scene.objects: o.select_set(False)
body.select_set(True); rig.select_set(True); bpy.context.view_layer.objects.active = rig
bpy.ops.object.parent_set(type='ARMATURE_AUTO')
wcount = np.zeros(n, np.int32)
for v in me.vertices: wcount[v.index] = sum(1 for g in v.groups if g.weight > 0.001)
print("unweighted verts", int((wcount == 0).sum()), "of", n)
if (wcount == 0).any():   # fallback: nearest bone gets full weight
    segs = [(b.name, b.head_local, b.tail_local) for b in ad.bones if b.use_deform]
    for vi in np.where(wcount == 0)[0]:
        p = me.vertices[int(vi)].co
        best = min(segs, key=lambda s: (p - (s[1] + (s[2] - s[1]) * max(0, min(1, (p - s[1]).dot(s[2] - s[1]) / max(1e-9, (s[2] - s[1]).length_squared))))).length)
        g = body.vertex_groups.get(best[0]) or body.vertex_groups.new(name=best[0])
        g.add([int(vi)], 1.0, 'REPLACE')

# ---------------------------------------------------------------- poses / actions
REST = {b.name: b.matrix_local.to_3x3() for b in ad.bones}
RDIR = {b.name: (b.tail_local - b.head_local).normalized() for b in ad.bones}
NRM = {s: ARMS[s]["n"] for s in ARMS}
FN = ["Index", "Middle", "Ring", "Pinky", "Thumb"]

class Pose:
    def __init__(self): self.rot, self.loc = {}, {}
    def r(self, bone, axis, deg):
        if abs(deg) > 1e-6: self.rot.setdefault(bone, []).append((Vector(axis).normalized(), deg))
        return self
    def swing(self, bone, target, deg):     # rotate the bone toward a direction
        ax = RDIR[bone].cross(Vector(target))
        if ax.length > 1e-6: self.r(bone, ax, deg)
        return self
    def l(self, bone, v): self.loc[bone] = self.loc.get(bone, V(0, 0, 0)) + Vector(v); return self
    def add(self, o, w=1.0):
        for b, lst in o.rot.items():
            for a, d in lst: self.r(b, a, d * w)
        for b, v in o.loc.items(): self.l(b, v * w)
        return self

def fingers(p, side, curls, spread=0.0):
    for fi, f in enumerate(FN):
        for k in range(3):
            c = curls[fi][k] if isinstance(curls[fi], (tuple, list)) else curls[fi]
            p.swing(f"{f}{k + 1}.{side}", NRM[side], c)
        if spread and f != "Thumb":
            p.swing(f"{f}1.{side}", RDIR["Hand." + side].cross(NRM[side]), spread * (fi - 1.5))

def idle_base():
    p = Pose()
    p.r("Spine", X, 5).r("Chest", X, 7).r("Chest", Z, 4).r("Chest", Y, -3)
    p.r("Neck", X, 14).r("Head", X, -6).r("Head", Y, 9)
    p.swing("Shoulder.L", UP, 5).swing("Shoulder.R", UP, -3)
    p.r("UpperArm.L", Y, 36).swing("UpperArm.L", FWD, 8)
    p.r("UpperArm.R", Y, -40).swing("UpperArm.R", FWD, 12)
    p.swing("ForeArm.L", FWD, 14).swing("ForeArm.R", FWD, 8)
    for s in "LR": p.swing("Hand." + s, NRM[s], 18)
    fingers(p, "L", [(12, 18, 14), (8, 14, 16), (16, 22, 12), (20, 24, 18), (6, 10, 8)])
    fingers(p, "R", [(18, 10, 22), (12, 16, 10), (10, 20, 18), (24, 18, 20), (10, 12, 6)])
    return p

def lookup_base():
    p = Pose()
    p.r("Spine", X, -6).r("Chest", X, -12).r("Chest", Z, 2)
    p.r("Neck", X, -24).r("Head", X, -34).r("Head", Y, 7)
    p.swing("Shoulder.L", UP, -6).swing("Shoulder.R", UP, -4)
    p.r("UpperArm.L", Y, 44).swing("UpperArm.L", FWD, -6)
    p.r("UpperArm.R", Y, -47).swing("UpperArm.R", FWD, -4)
    p.swing("ForeArm.L", FWD, 5).swing("ForeArm.R", FWD, 3)
    for s in "LR": p.swing("Hand." + s, NRM[s], 8)
    fingers(p, "L", [(6, 10, 8), (4, 8, 10), (10, 14, 6), (14, 16, 12), (2, 6, 4)], spread=4)
    fingers(p, "R", [(10, 6, 14), (8, 10, 6), (6, 12, 10), (16, 12, 14), (6, 8, 2)], spread=3)
    return p

def tails(p, w, amp=1.0):
    for t, ph in (("TailL", 0.0), ("TailR", 2.1), ("TailC", 4.0)):
        for k in range(1, 5):
            bn = f"{t}{k}"
            if bn not in REST: continue
            p.r(bn, X, amp * (3 + 2.5 * k) * math.sin(w + ph + k * 0.8))
            p.r(bn, Y, amp * (4 + 3 * k) * math.sin(w + ph + k * 0.8 + 1.2))

def pulse(u, c, wd): return math.exp(-((u - c) / wd) ** 2)
S = math.sin

def idle_motion(u):
    w = 2 * math.pi * u; p = Pose()
    p.l("Hips", V(0.02 * S(w + 0.7) + 0.007 * S(2 * w), 0.012 * S(2 * w + 2), 0.035 * S(w) + 0.01 * S(3 * w + 1)))
    p.r("Hips", Y, 2 * S(w + 1)).r("Hips", Z, 3 * S(w + 0.3))
    p.r("Spine", X, 1.5 * S(w + 0.5)).r("Chest", X, 2 * S(w + 1)).r("Chest", Y, 1.5 * S(2 * w))
    p.r("Neck", Z, 3 * S(w + 2))
    p.r("Head", X, 3 * S(2 * w + 1)).r("Head", Z, 5 * S(w + 0.4))
    p.r("Head", Y, 8 * pulse(u, 0.45, 0.015)).r("Head", X, -5 * pulse(u, 0.46, 0.012))
    p.swing("UpperArm.L", FWD, 4 * S(w + 1.3)).r("UpperArm.L", Y, 3 * S(2 * w))
    p.swing("UpperArm.R", FWD, 5 * S(w + 2.6)).r("UpperArm.R", Y, -3 * S(3 * w + 1))
    p.swing("ForeArm.L", FWD, 6 * S(2 * w + 0.4)).swing("ForeArm.R", FWD, 5 * S(2 * w + 2.2))
    for si, s in enumerate("LR"):
        p.swing("Hand." + s, NRM[s], 6 * S(2 * w + si * 1.7))
        for fi, f in enumerate(FN):
            for k in range(3):
                p.swing(f"{f}{k + 1}.{s}", NRM[s], 9 * S((2 + (fi + si) % 2) * w + fi * 1.3 + k * 0.6 + si))
    p.swing("Index1.R", NRM["R"], 25 * pulse(u, 0.78, 0.012))
    tails(p, w)
    return p

def lookup_motion(u):
    w = 2 * math.pi * u; p = Pose()
    p.l("Hips", V(0.01 * S(w + 1), 0.006 * S(2 * w), 0.022 * S(w) + 0.006 * S(3 * w)))
    p.r("Chest", X, 1 * S(w))
    p.r("Head", X, 1.2 * S(2 * w)).r("Head", Z, 1.5 * S(w + 1))
    p.r("Head", Z, 6 * pulse(u, 0.3, 0.01)).r("Head", X, -4 * pulse(u, 0.3, 0.012))
    p.r("Head", Y, -8 * pulse(u, 0.72, 0.01)).r("Neck", Y, -3 * pulse(u, 0.72, 0.014))
    for si, s in enumerate("LR"):
        for fi, f in enumerate(FN):
            for k in range(3):
                p.swing(f"{f}{k + 1}.{s}", NRM[s], 5 * S(2 * w + fi * 1.1 + k * 0.5 + si * 2))
    for f in FN[:4]:
        p.swing(f"{f}2.R", NRM["R"], 22 * pulse(u, 0.725, 0.01))
    tails(p, w, 0.7)
    return p

GLITCH_AMP = {"Head": 22, "Neck": 10, "Chest": 7, "Spine": 5, "Hips": 4,
              "UpperArm": 14, "ForeArm": 16, "Hand": 18, "Shoulder": 6, "Tail": 12}

def rand_jitter(scale):
    p = Pose()
    for b in REST:
        if b == "Root": continue
        key = next((k for k in GLITCH_AMP if b.startswith(k)), None)
        amp = GLITCH_AMP[key] if key else (25 if b[0] in "IMRPT" else 0)
        if amp:
            ax = V(random.gauss(0, 1), random.gauss(0, 1), random.gauss(0, 1))
            p.r(b, ax, random.gauss(0, 1) * amp * scale)
    p.l("Hips", V(random.gauss(0, 0.035), random.gauss(0, 0.02), random.gauss(0, 0.03)) * scale)
    return p

def arms_out():
    p = Pose()
    p.r("Spine", X, -4).r("Chest", X, -6).r("Neck", X, -10).r("Head", X, -14)
    p.r("UpperArm.L", Y, -32).swing("UpperArm.L", FWD, 14).r("UpperArm.R", Y, 30).swing("UpperArm.R", FWD, 10)
    p.swing("ForeArm.L", UP, 10).swing("ForeArm.R", UP, 8)
    for s in "LR":
        p.swing("Hand." + s, NRM[s], -10)
        fingers(p, s, [-10] * 5, spread=8)
    return p

def folded():
    p = Pose()
    p.l("Hips", V(0, 0.05, -0.55))
    p.r("Spine", X, 30).r("Chest", X, 35).r("Neck", X, 25).r("Head", X, 20).r("Head", Y, -12)
    p.r("UpperArm.L", Y, 12).swing("UpperArm.L", FWD, 30).r("UpperArm.R", Y, -10).swing("UpperArm.R", FWD, 28)
    for s in "LR":
        p.swing("ForeArm." + s, FWD, 20)
        fingers(p, s, [30] * 5)
    for t in ("TailL", "TailR", "TailC"):
        for k in range(1, 5):
            if f"{t}{k}" in REST: p.r(f"{t}{k}", X, 18)
    return p

def smooth01(x): x = max(0.0, min(1.0, x)); return x * x * (3 - 2 * x)

def make_action(name, frames, pose_fn, constant=False):
    act = bpy.data.actions.new(name); act.use_fake_user = True
    rig.animation_data_create(); rig.animation_data.action = act
    prev = {}
    for f in frames:
        p = pose_fn(f)
        for pb in rig.pose.bones:
            pb.rotation_mode = 'QUATERNION'
            R = Matrix.Identity(3)
            for a, d in p.rot.get(pb.name, []): R = Matrix.Rotation(math.radians(d), 3, a) @ R
            M = REST[pb.name]
            q = (M.inverted() @ R @ M).to_quaternion()
            if pb.name in prev and q.dot(prev[pb.name]) < 0: q.negate()
            prev[pb.name] = q.copy()
            pb.rotation_quaternion = q
            pb.location = M.inverted() @ p.loc.get(pb.name, V(0, 0, 0))
            pb.keyframe_insert("rotation_quaternion", frame=f, group=pb.name)
            pb.keyframe_insert("location", frame=f, group=pb.name)
    if constant:
        cb = anim_utils.action_get_channelbag_for_slot(act, rig.animation_data.action_slot)
        for fc in cb.fcurves:
            for kp in fc.keyframe_points: kp.interpolation = 'CONSTANT'
    act.frame_range = (frames[0], frames[-1])
    print("action", name, "keys", len(frames))
    return act

IDLE_T, LOOK_T = 240, 300
make_action("Idle", list(range(0, IDLE_T + 1, 2)),
            lambda f: idle_base().add(idle_motion(f / IDLE_T)))
make_action("LookUp", list(range(0, LOOK_T + 1, 2)),
            lambda f: lookup_base().add(lookup_motion(f / LOOK_T)))

def glitch_fn(length, amp, spread_pose=None):
    rnd = {}
    def fn(f):
        p = idle_base().add(idle_motion(0))
        if f in (0, length): return p
        env = math.sin(math.pi * f / length) ** 0.5
        if spread_pose is not None:
            p.add(spread_pose, smooth01(f / (length * 0.25)) * smooth01((length - f) / (length * 0.2)))
        if f not in rnd: rnd[f] = rand_jitter(amp * env * (1.6 if random.random() < 0.2 else 1.0))
        return p.add(rnd[f])
    return fn
make_action("Glitch", [0] + list(range(1, 45, 2)) + [45], glitch_fn(45, 1.0), constant=True)
make_action("GlitchAggressive", [0] + list(range(1, 75, 2)) + [75], glitch_fn(75, 1.5, arms_out()), constant=True)

def appear_fn(f):
    u = f / 60.0
    held = u
    for a, b in ((0.28, 0.36), (0.52, 0.58), (0.72, 0.76)):   # stutter holds
        if a <= u < b: held = a
    e = smooth01(held)
    p = idle_base().add(idle_motion(0), 1.0)
    if f < 60:
        p = Pose().add(folded(), 1 - e).add(idle_base(), e).add(idle_motion(0), e)
        if 0 < f < 56: p.add(rand_jitter(0.25 * (1 - e)))
    return p
make_action("Appear", list(range(0, 61, 2)), appear_fn)

def disappear_fn(f):
    p = idle_base().add(idle_motion(0))
    if f == 0: return p
    snap = smooth01(f / 6.0)
    p.add(arms_out(), snap)
    p.r("Head", X, -22 * snap).l("Hips", V(0, 0, 0.12 * snap + 0.3 * smooth01((f - 6) / 30)))
    p.add(rand_jitter(0.5 * snap))
    return p
make_action("Disappear", list(range(0, 37, 2)), disappear_fn)

def aim_angle(bone, target):
    return math.degrees(RDIR[bone].angle(Vector(target).normalized()))

def headtilt_fn(f, T=105):
    u = f / T
    p = idle_base().add(idle_motion(0))
    w = smooth01(u / 0.34) * smooth01((1 - u) / 0.3)          # ease in, hold, ease out
    tw = pulse(u, 0.52, 0.012)                                # sudden twitch at the peak
    p.r("Neck", Y, 12 * w).r("Neck", Z, -6 * w)
    p.r("Head", Y, 36 * w + 9 * tw).r("Head", Z, -8 * w - 5 * tw).r("Head", X, -4 * w)
    p.r("Head", X, 1.5 * math.sin(u * 40) * w)                # trembling hold
    p.r("Jaw", X, 8 * w)
    return p
make_action("HeadTilt", list(range(0, 106, 1)), headtilt_fn)

def lunge_fn(f, T=78):
    u = f / T
    p = idle_base().add(idle_motion(0))
    snap = smooth01(u / 0.12)
    raise_ = smooth01((u - 0.08) / 0.32)
    lunge = smooth01((u - 0.25) / 0.38)
    for b, lst in p.rot.items():   # fade the idle arm/head pose out so the reach aims from rest
        if b.split(".")[0] in ("Shoulder", "UpperArm", "ForeArm", "Hand", "Neck", "Head"):
            k = 1 - (raise_ if b.split(".")[0] not in ("Neck", "Head") else lunge)
            p.rot[b] = [(a, d * k) for a, d in lst]
    p.r("Head", X, -24 * snap * (1 - lunge)).r("Jaw", X, 26 * snap)
    reach = {"L": V(0.3, -1, 0.42), "R": V(-0.26, -1, 0.36)}
    for s_ in "LR":
        p.swing("UpperArm." + s_, reach[s_], aim_angle("UpperArm." + s_, reach[s_]) * raise_)
        p.swing("ForeArm." + s_, RDIR["UpperArm." + s_], aim_angle("ForeArm." + s_, RDIR["UpperArm." + s_]) * raise_)
        p.swing("Shoulder." + s_, FWD, 14 * raise_)
        p.swing("Hand." + s_, NRM[s_], -22 * raise_)
        fingers(p, s_, [(-12 * raise_, 18 * lunge, 28 * lunge)] * 4 + [(-8 * raise_, 10 * lunge, 12 * lunge)], spread=10 * raise_)
    p.l("Hips", V(0, -1.3 * lunge, 0.12 * lunge - 0.05 * snap))
    p.r("Spine", X, 16 * lunge).r("Chest", X, 10 * lunge - 8 * snap * (1 - lunge))
    p.r("Neck", X, 6 * lunge).r("Head", X, -16 * lunge).r("Head", Y, 10 * lunge)
    if 2 <= f <= T - 6:
        p.add(rand_jitter(0.55 + 0.45 * lunge))
    return p
make_action("FinalLunge", list(range(0, 79, 2)), lunge_fn)

rig.animation_data.action = None
for pb in rig.pose.bones:
    pb.rotation_quaternion = (1, 0, 0, 0); pb.location = (0, 0, 0)

bpy.ops.wm.save_as_mainfile(filepath=os.path.join(OUT, "ShadowEntity.blend"))

# ---------------------------------------------------------------- FBX
for o in scene.objects: o.select_set(o in (rig, body))
bpy.ops.export_scene.fbx(
    filepath=os.path.join(OUT, "ShadowEntity.fbx"), use_selection=True,
    object_types={'ARMATURE', 'MESH'}, apply_scale_options='FBX_SCALE_ALL',
    axis_forward='-Z', axis_up='Y', use_mesh_modifiers=True, mesh_smooth_type='FACE',
    add_leaf_bones=False, primary_bone_axis='Y', secondary_bone_axis='X',
    use_armature_deform_only=False, armature_nodetype='NULL',
    bake_anim=True, bake_anim_use_all_bones=True, bake_anim_use_nla_strips=False,
    bake_anim_use_all_actions=True, bake_anim_force_startend_keying=True,
    bake_anim_step=1.0, bake_anim_simplify_factor=0.0, path_mode='STRIP')
print("FBX written")

# ---------------------------------------------------------------- check renders
scene.render.engine = 'BLENDER_WORKBENCH'
scene.display.shading.light = 'STUDIO'
scene.display.shading.color_type = 'SINGLE'
scene.display.shading.single_color = (0.55, 0.55, 0.58)
scene.display.shading.show_cavity = True
scene.render.resolution_x, scene.render.resolution_y = 420, 560
world = bpy.data.worlds.new("W"); scene.world = world
cam = bpy.data.objects.new("Cam", bpy.data.cameras.new("Cam")); scene.collection.objects.link(cam)
scene.camera = cam; cam.data.lens = 50

def shot(path, loc, target, action=None, frame=0):
    rig.animation_data.action = bpy.data.actions[action] if action else None
    if action:
        rig.animation_data.action_slot = bpy.data.actions[action].slots[0]
    scene.frame_set(frame)
    cam.location = loc
    cam.rotation_euler = (Vector(target) - Vector(loc)).to_track_quat('-Z', 'Y').to_euler()
    scene.render.filepath = path
    bpy.ops.render.render(write_still=True)
    return path

shots = [shot(os.path.join(OUT, "chk_front.png"), (0, -5.2, 1.3), (0, 0, 1.25), "Idle", 0),
         shot(os.path.join(OUT, "chk_side.png"), (5.2, 0, 1.4), (0, 0, 1.3), "LookUp", 0),
         shot(os.path.join(OUT, "chk_lunge34.png"), (2.6, -4.4, 1.9), (0, -1.0, 1.5), "FinalLunge", 76),
         shot(os.path.join(OUT, "chk_face.png"), (0.25, -1.1, 2.2), (0, 0, 2.17), "HeadTilt", 50),
         shot(os.path.join(OUT, "chk_lookup_tower.png"), (0.4, -1.6, 5.2), (0, 0, 1.8), "LookUp", 0),
         shot(os.path.join(OUT, "chk_lunge_side.png"), (5.0, -1.2, 1.7), (0, -0.8, 1.6), "FinalLunge", 50)]
imgs = []
for pth in shots:
    im = bpy.data.images.load(pth); a = np.empty(len(im.pixels), np.float32)
    im.pixels.foreach_get(a); imgs.append(a.reshape(im.size[1], im.size[0], 4))
row1 = np.concatenate(imgs[:3], 1); row2 = np.concatenate(imgs[3:], 1)
sheet = np.concatenate([row2, row1], 0)  # image rows are bottom-up
out = bpy.data.images.new("sheet", sheet.shape[1], sheet.shape[0], alpha=True)
out.pixels.foreach_set(sheet.ravel()); out.filepath_raw = os.path.join(OUT, "check_sheet.png")
out.file_format = 'PNG'; out.save()
for pth in shots: os.remove(pth)
print("DONE")
